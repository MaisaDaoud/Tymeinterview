import setuptools

setuptools.setup(

    install_requires=[

        'cloudml-hypertune',

    ],

    packages=setuptools.find_packages())
